import os,sys,json,urllib.request,re
# usage: .ds.py model prompt_file out_file
model,pf,out=sys.argv[1:4]
prompt=open(pf).read()
body={"model":model,"messages":[{"role":"system","content":"你是资深 TypeScript 游戏程序员。只输出一个完整文件的代码，用 ```ts 代码块包裹，不要解释。"},{"role":"user","content":prompt}],"max_tokens":32000}
req=urllib.request.Request("https://api.deepseek.com/chat/completions",data=json.dumps(body).encode(),headers={"Content-Type":"application/json","Authorization":"Bearer "+os.environ["DEEPSEEK_API_KEY"]})
try:
  r=json.load(urllib.request.urlopen(req,timeout=900))
except urllib.error.HTTPError as e:
  print("HTTP",e.code,e.read().decode()[:300]);sys.exit(1)
txt=r["choices"][0]["message"]["content"]
L=txt.split("\n");idx=[i for i,l in enumerate(L) if l.strip().startswith("```")]
while len(idx)>=2 and L[idx[0]+1].strip().startswith("```"): idx.pop(0)
code="\n".join(L[idx[0]+1:idx[-1]]) if len(idx)>=2 else txt
open("/tmp/ds_raw.txt","w").write(txt)
os.makedirs(os.path.dirname(out) or ".",exist_ok=True)
open(out,"w").write(code)
print("ok",r["choices"][0].get("finish_reason"),r.get("model"),len(code),r.get("usage",{}).get("total_tokens"))
