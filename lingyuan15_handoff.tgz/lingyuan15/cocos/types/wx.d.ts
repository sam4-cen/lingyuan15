declare const wx: any;
