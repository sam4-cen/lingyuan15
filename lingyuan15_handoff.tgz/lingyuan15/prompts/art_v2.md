# 美术素材接入约定（替换占位）
目录（Cocos 工程内）：
- assets/resources/art/<anim>/<i>.png 序列帧（i 从 0 开始）；单张图是 <name>/0.png。已有 anim：hero_idle(6) hero_walk(6) hero_dig(6) hero_fall_sleep(4) box_bag_shake(3,32px) box_bin_shake(3,48px) box_scrap_shake(3,48px) glow_white/blue/gold/rainbow(6,48px) fx_lidpop(5,48px) npc_patrol_uncle(4) npc_guard(4) npc_rival(4) npc_cat(4) npc_kind_auntie(4) npc_delivery_rider(3) npc_sanitation_auntie(3) npc_wallet_owner(3) fortune_cup(7,64x96，第0帧静止，1~6帧摇晃循环) fortune_slip(1,空白签面) card_daily card_fail card_cert(300x400) bar_frame_red/yellow(9宫格 inset 3/3/3/3) bar_frame_blue(inset 2/2/2/2) button_normal(inset L2 R2 T2 B4) button_pressed(inset L5 R5 T4 B5) panel_frame(inset L5 R3 T5 B5) inv_grid_*（5x5 整块面板，不使用；背包单格由代码 Graphics 画框）。
- assets/resources/art/icons/<iconName>.png 16x16 物品图标。
- 背景在 Asset Bundle「bg」（assets/bundles/bg，微信分包）：<name>.png，名字：loc_huaqiangbei loc_dongmen loc_baishizhou loc_futian_cbd loc_nanshan_tech loc_bg_compound loc_night_market loc_fastfood_back shelter_bed shelter_bed_up shelter_recycle sleep_park sleep_fastfood sleep_netcafe map_shenzhen(360x640)。用 assetManager.loadBundle('bg') 后 bundle.load(name+'/spriteFrame', SpriteFrame)；进入游戏后后台预加载，未加载完时用占位色块，加载完替换。
- 不接入（继续代码占位）：fx_flashlight、fx_clash、物品弹出闪光 pop_flash、回收站升级版 home_2。

## 逻辑名 → 素材名（写成 assets/scripts/ui/ArtMap.ts 导出 const ART_ALIAS: Record<string,{src:'res'|'bg', path:string, fps?:number, loopFrom?:number, insets?:[number,number,number,number]}> 以及 ICON_MAP: Record<itemId,string> 和 MAP_POINTS: Record<locationId,{x:number,y:number}>）
hero_idle→hero_idle, hero_walk→hero_walk, hero_dig→hero_dig, hero_fall→hero_fall_sleep, box_small→box_bag_shake, box_big→box_bin_shake（大盒另一种外观 box_big_alt→box_scrap_shake，偶数编号盒子用 alt）, glow_*→glow_*, lid_pop→fx_lidpop, npc_patrol/ev_patrol→npc_patrol_uncle, npc_guard/ev_guard→npc_guard, npc_rival/ev_rival→npc_rival, npc_cat/ev_cat→npc_cat, npc_auntie/ev_auntie→npc_kind_auntie, npc_courier/ev_delivery→npc_delivery_rider, ev_wallet→npc_wallet_owner, npc_sanitation/ev_night_warmth→npc_sanitation_auntie, fortune_tube→fortune_cup(loopFrom 1), fortune_slip, card_day→card_daily, card_fail, card_cert, bar_hunger→bar_frame_yellow, bar_stamina→bar_frame_red, bar_mood→bar_frame_blue, button→button_normal, button_pressed, panel→panel_frame；
bg_huaqiangbei/dongmen/baishizhou/futian_cbd/nanshan_tech→bg 同名 loc_*；bg_sz_bay、bg_window_world、bg_university_town 没有素材→占位；map→map_shenzhen；home_0→shelter_bed，home_1→shelter_recycle，home_2→占位；sleep_bench→sleep_park，sleep_diner→sleep_fastfood，sleep_netcafe→sleep_netcafe。
ICON_MAP：empty_water_bottle→plastic_bottle, crushed_can→soda_can, cardboard_box→cardboard, left_slipper→left_slipper, broken_umbrella→umbrella, half_cup_milk_tea→milk_tea, cold_bun→buns, half_egg_tart→egg_tart, expired_bread→bread, charging_cable→charger_cable, energy_drink→tin_can, delivery_set_meal→rice_box, exam_materials→old_book, mechanical_keyboard→keyboard, old_phone→old_phone, scratch_card→scratch_card, dead_mouse→dead_mouse；其余物品没有图标→占位色块+名字首字。
MAP_POINTS（地图 360x640 像素坐标，原点左上）：university_town 210,154；huaqiangbei 301,216；nanshan_tech 43,264；baishizhou 178,301；window_world 106,311；dongmen 329,357；futian_cbd 244,403；sz_bay 59,421。显示时地图按高度适配 1280（缩放 2x 即 720x1280），坐标换算成以节点中心为原点的 Cocos 坐标：cx=(x-180)*2, cy=(320-y)*2。

## Art.ts 改动
- preload()：resources.loadDir('art', SpriteFrame) 全部加载；所有 SpriteFrame 的 texture 设置 setFilters(Texture2D.Filter.NEAREST, Texture2D.Filter.NEAREST) 保证像素清晰；有 insets 的设置 spriteFrame.insetLeft/Right/Top/Bottom。然后后台 loadBundle('bg') 并加载所有背景。
- frames(name)：先查 ART_ALIAS 解析到真实路径，再取帧（res 的 art/<path>/0..n 按数字排序；bg 单帧）；icon_<itemId> 走 ICON_MAP → art/icons/<iconName>。
- makeVisual(name,w,h,color,label)：有帧→Sprite（sizeMode CUSTOM，宽高为 w,h；有 insets 时 type=SLICED）并按 fps(默认10) 播放，loopFrom 指定循环起点；无帧→保持原来的色块+文字占位。如果是 bg 且还没加载完，先占位，加载完自动替换成 Sprite。
- 新增 static makeCard(kind:'card_day'|'card_fail'|'card_cert', parentH:number):Node：卡片按高度适配：高度 = parentH*0.7，宽 = 高*0.75，水平居中两边留空；底图为卡片素材，上面挂一个 content 子节点供写文字。
- 新增 static makeButton(text, w, h, onClick):Node 用 button 九宫格（无素材时色块），按下切 button_pressed。
- 新增 static drawCell(g:Graphics, x, y, size, state:'normal'|'hover'|'bad'|'filled')：代码画单个背包格（深色底+2px 浅色边框，hover 黄边，bad 红边）。
- 新增 static missing():string[] 返回本次运行中被请求但没有素材、走了占位的逻辑名（去重），用于报告。
保持原有公开方法签名兼容（preload/frames/makeVisual/play）。
